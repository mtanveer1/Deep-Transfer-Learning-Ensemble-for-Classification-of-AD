import pickle
import pandas as pd
import datetime
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras import applications
from tensorflow.keras import optimizers
from tensorflow.keras.models import Sequential, Model, load_model
from tensorflow.keras.layers import Dropout, Flatten, Dense
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Activation
from DataGen_BinaryLabels import DataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.callbacks import TensorBoard
from tensorflow.keras import backend as K
import math
#import os
import glob
from tensorflow.keras.layers import *
from tensorflow.keras.callbacks import Callback

class Snapshot(Callback):

    def __init__(self, folder_path, nb_epochs, nb_cycles=5, verbose=0):
        if nb_cycles > nb_epochs:
            raise ValueError('nb_epochs has to be lower than nb_cycles.')

        super(Snapshot, self).__init__()
        self.verbose = verbose
        self.folder_path = folder_path
        self.nb_epochs = nb_epochs
        self.nb_cycles = nb_cycles
        self.period = self.nb_epochs // self.nb_cycles
        self.nb_digits = len(str(self.nb_cycles))
        self.path_format = os.path.join(self.folder_path, 'weights_cycle_{}.h5')


    def on_epoch_end(self, epoch, logs=None):
        if epoch == 0 or (epoch + 1) % self.period != 0: return
        # Only save at the end of a cycle, a not at the beginning

        if not os.path.exists(self.folder_path):
            os.makedirs(self.folder_path)

        cycle = int(epoch / self.period)
        cycle_str = str(cycle).rjust(self.nb_digits, '0')
        self.model.save_weights(self.path_format.format(cycle_str), overwrite=True)

        # Resetting the learning rate
        K.set_value(self.model.optimizer.lr, self.base_lr)

        if self.verbose > 0:
            print('\nEpoch %05d: Reached %d-th cycle, saving model.' % (epoch, cycle))


    def on_epoch_begin(self, epoch, logs=None):
        if epoch <= 0: return

        lr = self.schedule(epoch)
        K.set_value(self.model.optimizer.lr, lr)

        if self.verbose > 0:
            print('\nEpoch %05d: Snapchot modifying learning '
                  'rate to %s.' % (epoch + 1, lr))


    def set_model(self, model):
        self.model = model
        if not hasattr(self.model.optimizer, 'lr'):
            raise ValueError('Optimizer must have a "lr" attribute.')

        # Get initial learning rate
        self.base_lr = float(K.get_value(self.model.optimizer.lr))


    def schedule(self, epoch):
        lr = math.pi * (epoch % self.period) / self.period
        lr = self.base_lr / 2 * (math.cos(lr) + 1)
        return lr
    
#returns a list  of  hyperparamter settings
def load_hyperparameter_settings(sampler_file):
    hyp_list = []
    
    with open(sampler_file, "rb") as obj:
        for i in range(10):
            hyp_list.append(pickle.load(obj))
            
    return hyp_list

#returns VGG16 base_model
def load_base_model_vgg16(img_width,img_height,num_channels,weight_init='imagenet',include_fc_layers=False):
    base_model = applications.VGG16(weights=weight_init, input_shape=(img_width, img_height, num_channels)
                                    ,include_top=include_fc_layers)
    return base_model

#hyperparam_setting - dictionary of hyperparameter setting
#base_model - the base model to fine tune
#returns the full model after adding the FC layers to the base_model

def add_fc_layers(hyperparam_setting, base_model):
    num_layers = hyperparam_setting['layers']
    nodes_fc_layer_1 = int(hyperparam_setting['nodes_1'])
    
    print('Dense('+str(nodes_fc_layer_1)+'), use_bias = False)(X)')
    print('BatchNormalization()(X)')
    print('Activation(relu)(X)')
    print('Dropout(0.3)(X)')
    
    X = base_model.output
    X = Flatten(input_shape=base_model.output_shape[1:])(X)
    
    X = Dense(nodes_fc_layer_1, use_bias = False)(X)
    X = BatchNormalization()(X)
    X = Activation('relu')(X)
    X = Dropout(0.3)(X)  
    
    if num_layers > 1:
        print('more than one layer')
        
        for n_layer in range(2,num_layers+1):
            #str(setting['nodes_'+str(n_layer)
            
            num_nodes = int(hyperparam_setting['nodes_'+str(n_layer)])
            X = Dense(num_nodes, use_bias = False)(X)
            X = BatchNormalization()(X)
            X = Activation('relu')(X)
            X = Dropout(0.3)(X)  
            
            print('Dense('+str(num_nodes)+'), use_bias = False)(X)')
            print('BatchNormalization()(X)')
            print('Activation(relu)(X)')
            print('Dropout(0.3)(X)')
    else:
        print('only one layer')
        
    Output = Dense(1, use_bias = False)(X) #number of dense nodes is 1 because it is a binary classification problem
    Output = BatchNormalization()(Output)
    Output = Activation('sigmoid')(Output)
    
    model = Model(inputs=base_model.input, outputs=Output)
    return model

#set the first num_layers to nontrainable
#model - an instance of Keras Model
# => model is the final model (base_model added with fully connected layers)

def set_nontrainable_layers(num_layers, model):
    for layer in model.layers[:num_layers]:
        layer.trainable = False
        
    return model

#model - an instance of Keras Model
# => model is the final model (base_model added with fully connected layers)

def add_loss_function(hyperparam_setting, model, metric = 'accuracy'):
    learning_rate = hyperparam_setting['learning_rate']
    
    model.compile(loss='binary_crossentropy',
                  optimizer=optimizers.Adam(lr = learning_rate),
                  metrics=[metric])
    
    return model

#returns the dict of cross validation settings

def load_cross_validation_settings(cv_file):
    cv_setting = None
    with open(cv_file, "rb") as obj:
        cv_setting = pickle.load(obj)
        
    return cv_setting
    
    
    
def fit_generator(hyperparameter_setting, training_generator, 
                  model, setting_count, cv_fold_idx,
                  save_best_model_only=False):
    #print("==========")
    cbs = [Snapshot('snapshots', nb_epochs=6, verbose=1, nb_cycles=3)]
    num_epochs = hyperparameter_setting['epochs']
    history = model.fit(
                training_generator,
                epochs = 50,
                callbacks=cbs,
                verbose=1
                )
    
    #print(datetime.datetime.now())
    
   # del checkpointer
    return history


def fit_full_training_data(hyperparameter_setting, cv_file, 
                         generator_params_dict, history_path,
                         setting_count, original_model_path,
                         model_name):
        
        cv_setting = load_cross_validation_settings(cv_file)
        train = cv_setting['Train']
        
        cur_train = train[1]

        final_train = cur_train['Train']
        final_validation = cur_train['Validation']
        
        subject_dict_train = {}
        subject_list_train = []
        for x,y in zip(final_train[0], final_train[1]):
            subject_list_train.append(x)
            subject_dict_train[x] = y
            
        subject_dict_val = {}
        subject_list_val = []
        for x,y in zip(final_validation[0], final_validation[1]):
            subject_list_val.append(x)
            subject_dict_val[x] = y
        
        temp_dict = subject_dict_train.copy()
        temp_dict.update(subject_dict_val)
        full_subject_list = subject_list_train + subject_list_val
        
        training_generator = DataGenerator(subject_list_val, temp_dict, **generator_params_dict)
        history = fit_generator(hyperparameter_setting, training_generator, 
                                model_name, setting_count, 1,
                               False)
        
        model_name.save('DTE_snapshot.hdf5')
        #backend.clear_session()
        
       
    
img_width = 256
img_height = 256
num_channels = 3

history_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD/history'
sampler_file = r'DTE_ADNI_Baseline_Axial_CN_vs_AD_First10_Iters.pkl'
checkpoint_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD/model_checkpoints'
base_save_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD'
cv_file = '/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_CN_vs_AD_CV_File.pickle'

base_model = load_base_model_vgg16(img_width,img_height,num_channels)
model = tf.keras.layers.Flatten()(base_model.output)
model = tf.keras.layers.Dense(100)(model)
model_out = tf.keras.layers.Dense(1)(model)
final_model = Model(inputs = base_model.input, outputs = model_out)

final_model.compile(optimizer=optimizers.Adam(0.01), loss='binary_crossentropy')

params_dict = {'dim':(img_width,img_height),
                   'batch_size': 16,
                   'n_classes': 2,
                   'n_channels': num_channels,
                   'shuffle':False
                  }
hyperparam_list = load_hyperparameter_settings(sampler_file)
hyperparam = hyperparam_list[0]
fit_full_training_data(hyperparam, cv_file, params_dict, history_path,
                         0, '', final_model)


# print(datetime.datetime.now())
# setting_count = 1

# print("****** Okay Jarvis!!!! Light it up ******")
# for hyperparam in hyperparam_list:
    
# #     if setting_count < 3:
# #         setting_count = setting_count + 1
# #         continue
    
#     print("hyperparam setting: "+str(setting_count))
#     print(hyperparam)
    
#     base_model = load_base_model_vgg16(img_width,img_height,num_channels)
#     model = add_fc_layers(hyperparam,base_model)   
#     model = set_nontrainable_layers(19,model)
#     model = add_loss_function(hyperparam,model)
    
#     original_model_path = base_save_path + '/original_models/' +str(setting_count)+'.hdf5'
#     model.save(original_model_path)
    
#     print(model.summary())
    
#     params_dict = {'dim':(img_width,img_height),
#                    'batch_size': hyperparam['batch_size'],
#                    'n_classes': 2,
#                    'n_channels': num_channels,
#                    'shuffle':False
#                   }
    
#     fit_cross_validation(hyperparam, cv_file, params_dict, history_path,
#                          setting_count, original_model_path, False)
    
#     setting_count = setting_count + 1
#     print("******")
#     del model, base_model

# print("******** THE END SIR; IS IT JARVIS??? *********")
# print(datetime.datetime.now())
