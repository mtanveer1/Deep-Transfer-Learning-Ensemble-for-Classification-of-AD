import pickle
import pandas as pd
import datetime
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras import applications
from tensorflow.keras import optimizers
from tensorflow.keras.models import Sequential, Model, load_model
from tensorflow.keras.layers import Dropout, Flatten, Dense
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import Activation
from DataGen_BinaryLabels import DataGenerator
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.callbacks import TensorBoard
from tensorflow.keras import backend

#returns a list  of  hyperparamter settings
def load_hyperparameter_settings(sampler_file):
    hyp_list = []
    
    with open(sampler_file, "rb") as obj:
        for i in range(10):
            hyp_list.append(pickle.load(obj))
            
    return hyp_list

#returns VGG16 base_model
def load_base_model_vgg16(img_width,img_height,num_channels,weight_init='imagenet',include_fc_layers=False):
    base_model = applications.VGG16(weights=weight_init, input_shape=(img_width, img_height, num_channels)
                                    ,include_top=include_fc_layers)
    return base_model

#hyperparam_setting - dictionary of hyperparameter setting
#base_model - the base model to fine tune
#returns the full model after adding the FC layers to the base_model

def add_fc_layers(hyperparam_setting, base_model):
    num_layers = hyperparam_setting['layers']
    nodes_fc_layer_1 = int(hyperparam_setting['nodes_1'])
    
    print('Dense('+str(nodes_fc_layer_1)+'), use_bias = False)(X)')
    print('BatchNormalization()(X)')
    print('Activation(relu)(X)')
    print('Dropout(0.3)(X)')
    
    X = base_model.output
    X = Flatten(input_shape=base_model.output_shape[1:])(X)
    
    X = Dense(nodes_fc_layer_1, use_bias = False)(X)
    X = BatchNormalization()(X)
    X = Activation('relu')(X)
    X = Dropout(0.3)(X)  
    
    if num_layers > 1:
        print('more than one layer')
        
        for n_layer in range(2,num_layers+1):
            #str(setting['nodes_'+str(n_layer)
            
            num_nodes = int(hyperparam_setting['nodes_'+str(n_layer)])
            X = Dense(num_nodes, use_bias = False)(X)
            X = BatchNormalization()(X)
            X = Activation('relu')(X)
            X = Dropout(0.3)(X)  
            
            print('Dense('+str(num_nodes)+'), use_bias = False)(X)')
            print('BatchNormalization()(X)')
            print('Activation(relu)(X)')
            print('Dropout(0.3)(X)')
    else:
        print('only one layer')
        
    Output = Dense(1, use_bias = False)(X) #number of dense nodes is 1 because it is a binary classification problem
    Output = BatchNormalization()(Output)
    Output = Activation('sigmoid')(Output)
    
    model = Model(inputs=base_model.input, outputs=Output)
    return model

#set the first num_layers to nontrainable
#model - an instance of Keras Model
# => model is the final model (base_model added with fully connected layers)

def set_nontrainable_layers(num_layers, model):
    for layer in model.layers[:num_layers]:
        layer.trainable = False
        
    return model

#model - an instance of Keras Model
# => model is the final model (base_model added with fully connected layers)

def add_loss_function(hyperparam_setting, model, metric = 'accuracy'):
    learning_rate = hyperparam_setting['learning_rate']
    
    model.compile(loss='binary_crossentropy',
                  optimizer=optimizers.Adam(lr = learning_rate),
                  metrics=[metric])
    
    return model

#returns the dict of cross validation settings

def load_cross_validation_settings(cv_file):
    cv_setting = None
    with open(cv_file, "rb") as obj:
        cv_setting = pickle.load(obj)
        
    return cv_setting
    
    
    
def fit_generator(hyperparameter_setting, training_generator, 
                  validation_generator, model, setting_count, cv_fold_idx,
                  save_best_model_only=False):
    #print("==========")

    num_epochs = hyperparameter_setting['epochs']
   
   
    
   # checkpoint_path = r'D:\Ashraf - Thesis\CN vs AD\Train\NPY_GM\checkpoints'
    
#     checkpointer = ModelCheckpoint(filepath = checkpoint_path+"\\hyperparam_setting_"+str(setting_count)
#                                                              +"_fold_"+str(cv_fold_idx)
#                                                              +"_weights_{epoch:02d}_{val_loss:.2f}.hdf5", 
#                                    monitor = 'val_acc',
#                                    verbose=1, 
#                                    save_best_only=save_best_model_only)
    
    history = model.fit(
                training_generator,
                epochs = num_epochs,
                validation_data = validation_generator,
                verbose=1
                )
    
    #print(datetime.datetime.now())
    
   # del checkpointer
    return history


#history = model history
#cv index = the current fold number for k fold cross validation

def save_model_history(history, cv_index, history_path, setting_count):
    print(history.history.keys())
    df_train_acc = pd.DataFrame(history.history['accuracy'])
    df_train_acc.columns = ['train_accuracy']
    
    df_train_loss = pd.DataFrame(history.history['loss'])
    df_train_loss.columns = ['train_loss']
    
    df_val_acc = pd.DataFrame(history.history['val_accuracy'])
    df_val_acc.columns = ['validation_accuracy']
    
    df_val_loss = pd.DataFrame(history.history['val_loss'])
    df_val_loss.columns = ['validation_loss']
    
    df_history = pd.concat([df_train_acc,df_val_acc,df_train_loss,df_val_loss],axis=1)
    df_history.to_csv(history_path+"/hyperparam_setting_"+str(setting_count)+"history_fold_"+str(cv_index)+".csv",
                      index=False)

    
def fit_cross_validation(hyperparameter_setting, cv_file, 
                         generator_params_dict, history_path,
                         setting_count, original_model_path,
                         save_best_model_only=False):
        
        cv_setting = load_cross_validation_settings(cv_file)
        train = cv_setting['Train']
    
        for idx in train.keys():
            model = load_model(original_model_path)
            cur_train = train[idx]
        
            final_train = cur_train['Train']
            final_validation = cur_train['Validation']
        
            subject_dict_train = {}
            subject_list_train = []
            for x,y in zip(final_train[0], final_train[1]):
                subject_list_train.append(x)
                subject_dict_train[x] = y
            
            subject_dict_val = {}
            subject_list_val = []
            for x,y in zip(final_validation[0], final_validation[1]):
                subject_list_val.append(x)
                subject_dict_val[x] = y
        
        
            training_generator = DataGenerator(subject_list_train, subject_dict_train, **generator_params_dict)
            validation_generator = DataGenerator(subject_list_val, subject_dict_val, **generator_params_dict)
        
            history = fit_generator(hyperparameter_setting, training_generator, 
                                validation_generator, model, setting_count, idx,
                               save_best_model_only)
        
            save_model_history(history, idx, history_path, setting_count)
            backend.clear_session()
        
       
    
img_width = 256
img_height = 256
num_channels = 3

history_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD/history/Second10_Iters'
sampler_file = r'DTE_ADNI_Baseline_Axial_CN_vs_AD_Second10_Iters.pkl'
checkpoint_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD/model_checkpoints'
base_save_path = r'/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_Revision/CN_vs_AD'
cv_file = '/media/iitindmaths/Seagate_Expansion_Drive/DTE_ADNI_Baseline_CN_vs_AD_CV_File.pickle'

hyperparam_list = load_hyperparameter_settings(sampler_file)

print(datetime.datetime.now())
setting_count = 1

print("****** Okay Jarvis!!!! Light it up ******")
for hyperparam in hyperparam_list:
    
#     if setting_count < 3:
#         setting_count = setting_count + 1
#         continue
    
    print("hyperparam setting: "+str(setting_count))
    print(hyperparam)
    
    base_model = load_base_model_vgg16(img_width,img_height,num_channels)
    model = add_fc_layers(hyperparam,base_model)   
    model = set_nontrainable_layers(19,model)
    model = add_loss_function(hyperparam,model)
    
    original_model_path = base_save_path + '/original_models/Second10_Iters/' +str(setting_count)+'.hdf5'
    model.save(original_model_path)
    
    print(model.summary())
    
    params_dict = {'dim':(img_width,img_height),
                   'batch_size': hyperparam['batch_size'],
                   'n_classes': 2,
                   'n_channels': num_channels,
                   'shuffle':False
                  }
    
    fit_cross_validation(hyperparam, cv_file, params_dict, history_path,
                         setting_count, original_model_path, False)
    
    setting_count = setting_count + 1
    print("******")
    del model, base_model

print("******** THE END SIR; IS IT JARVIS??? *********")
print(datetime.datetime.now())
